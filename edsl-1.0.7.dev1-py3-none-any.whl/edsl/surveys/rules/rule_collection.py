"""A collection of rules for a survey."""

from typing import List, Any, Optional
from collections import defaultdict, UserList, namedtuple

from ..exceptions import (
    SurveyRuleCannotEvaluateError,
    SurveyRuleCollectionHasNoRulesAtNodeError,
)

from .rule import Rule
from ..base import EndOfSurvey
from ..dag import DAG

NextQuestion = namedtuple(
    "NextQuestion", "next_q, num_rules_found, expressions_evaluating_to_true, priority"
)


class RuleCollection(UserList):
    """A collection of rules for a particular survey."""

    def __init__(
        self,
        num_questions: Optional[int] = None,
        rules: List[Rule] = None,
        question_name_to_index: Optional[dict] = None,
    ):
        """Initialize the RuleCollection object.

        :param num_questions: The number of questions in the survey.
        :param rules: A list of Rule objects.
        :param question_name_to_index: Shared mapping of question names to indices.
        """
        super().__init__(rules or [])
        self.num_questions = num_questions

        # Initialize shared question_name_to_index
        if question_name_to_index is not None:
            self._question_name_to_index = question_name_to_index
        else:
            # Build from existing rules if any
            self._question_name_to_index = {}
            for rule in self.data:
                self._question_name_to_index.update(rule.question_name_to_index)

        # Point all rules to the shared map
        for rule in self.data:
            rule.question_name_to_index = self._question_name_to_index

    @property
    def question_name_to_index(self) -> dict:
        """Return the shared question name to index mapping."""
        return self._question_name_to_index

    @question_name_to_index.setter
    def question_name_to_index(self, value: dict) -> None:
        """Set the shared question name to index mapping and update all rules."""
        self._question_name_to_index = value
        for rule in self.data:
            rule.question_name_to_index = self._question_name_to_index

    def __repr__(self):
        """Return a string representation of the RuleCollection object.

        Example usage:

        .. code-block:: python

            rule_collection = RuleCollection.example()
            _ = eval(repr(rule_collection))

        """
        return f"RuleCollection(rules={self.data}, num_questions={self.num_questions})"

    def to_dataset(self):
        """Return a Dataset object representation of the RuleCollection object."""
        from ...dataset import Dataset

        keys = ["current_q", "expression", "next_q", "priority", "before_rule"]
        rule_list = {}
        for rule in sorted(self, key=lambda r: r.current_q):
            for k in keys:
                rule_list.setdefault(k, []).append(getattr(rule, k))

        return Dataset([{k: v} for k, v in rule_list.items()])

    def _repr_html_(self):
        """Return an HTML representation of the RuleCollection object.

        >>> rule_collection = RuleCollection.example()
        >>> _ = rule_collection._repr_html_()
        """
        return self.to_dataset()._repr_html_()

    def to_dict(self, add_edsl_version=True):
        """Create a dictionary representation of the RuleCollection object.

        The question_name_to_index mapping is stored once at the collection level
        rather than in each rule, reducing serialization size from O(n²) to O(n).

        >>> rule_collection = RuleCollection.example()
        >>> rule_collection_dict = rule_collection.to_dict()
        >>> new_rule_collection = RuleCollection.from_dict(rule_collection_dict)
        >>> rule_collection.question_name_to_index == new_rule_collection.question_name_to_index
        True
        """
        rules = []
        for rule in self:
            rule_dict = rule.to_dict(include_question_name_to_index=False)
            # Include minimal map per rule for backward compatibility with old versions
            # that expect question_name_to_index in each rule.
            # Only includes question names referenced in this rule's expression.
            rule_dict["question_name_to_index"] = {
                name: self._question_name_to_index[name]
                for name in rule._extracted_question_names
                if name in self._question_name_to_index
            }
            rules.append(rule_dict)
        return {
            "question_name_to_index": self._question_name_to_index,
            "rules": rules,
            "num_questions": self.num_questions,
        }

    @classmethod
    def from_dict(cls, rule_collection_dict):
        """Create a RuleCollection object from a dictionary.

        Handles both old format (question_name_to_index in each rule) and
        new format (question_name_to_index at collection level).

        >>> rule_collection = RuleCollection.example()
        >>> rule_collection_dict = rule_collection.to_dict()
        >>> new_rule_collection = RuleCollection.from_dict(rule_collection_dict)
        >>> rule_collection.question_name_to_index == new_rule_collection.question_name_to_index
        True
        """
        # Check if new format (has top-level question_name_to_index)
        shared_map = rule_collection_dict.get("question_name_to_index", None)

        rules = []
        for rule_dict in rule_collection_dict["rules"]:
            # Old format: rule has its own non-empty map
            # New format: shared map at collection level, rules have empty or no map
            rule_map = rule_dict.get("question_name_to_index")
            if not rule_map:  # None, missing, or empty dict
                if not shared_map:
                    raise ValueError(
                        "Rule missing question_name_to_index and no shared map provided"
                    )
                rule_dict = {**rule_dict, "question_name_to_index": shared_map}
            rules.append(Rule.from_dict(rule_dict))

        num_questions = rule_collection_dict["num_questions"]

        # For new format, pass the shared map to constructor
        # For old format, constructor will build it from rules
        new_rc = cls(rules=rules, question_name_to_index=shared_map)
        new_rc.num_questions = num_questions
        return new_rc

    def add_rule(self, rule: Rule) -> None:
        """Add a rule to a survey.

        >>> rule_collection = RuleCollection()
        >>> rule_collection.add_rule(Rule(current_q=1, expression="{{ q1.answer }} == 'yes'", next_q=3, priority=1, question_name_to_index={'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4}))
        >>> len(rule_collection)
        1

        >>> rule_collection = RuleCollection()
        >>> r = Rule(current_q=1, expression="True", next_q=3, priority=1, question_name_to_index={'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4}, before_rule = True)
        >>> rule_collection.add_rule(r)
        >>> rule_collection[0] == r
        True
        >>> len(rule_collection.applicable_rules(1, before_rule=True))
        1
        >>> len(rule_collection.applicable_rules(1, before_rule=False))
        0
        """
        # Update shared map with rule's map entries
        self._question_name_to_index.update(rule.question_name_to_index)
        # Point rule to the shared map
        rule.question_name_to_index = self._question_name_to_index

        self.append(rule)

        # Clear the rules cache when new rules are added
        if hasattr(self, "_rules_cache"):
            self._rules_cache.clear()

    def show_rules(self) -> None:
        """Print the rules in a table."""
        return self.to_dataset()

    def skip_question_before_running(self, q_now: int, answers: dict[str, Any]) -> bool:
        """Determine if a question should be skipped before running the question.

        :param q_now: The current question index.
        :param answers: The answers to the survey questions.

        >>> rule_collection = RuleCollection()
        >>> r = Rule(current_q=1, expression="True", next_q=2, priority=1, question_name_to_index={}, before_rule = True)
        >>> rule_collection.add_rule(r)
        >>> rule_collection.skip_question_before_running(1, {})
        True

        >>> rule_collection = RuleCollection()
        >>> r = Rule(current_q=1, expression="False", next_q=2, priority=1, question_name_to_index={}, before_rule = True)
        >>> rule_collection.add_rule(r)
        >>> rule_collection.skip_question_before_running(1, {})
        False
        """
        for rule in self.applicable_rules(q_now, before_rule=True):
            if rule.evaluate(answers):
                return True
        return False

    def applicable_rules(self, q_now: int, before_rule: bool = False) -> list:
        """Show the rules that apply at the current node.

        :param q_now: The current question index.
        :param before_rule: If True, return rules that are of the type that apply before the question is asked.

        Example usage:

        >>> rule_collection = RuleCollection.example()
        >>> rule_collection.applicable_rules(1)
        [Rule(current_q=1, expression="{{ q1.answer }} == 'yes'", next_q=3, priority=1, question_name_to_index={'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4}, before_rule=False), Rule(current_q=1, expression="{{ q1.answer }} == 'no'", next_q=2, priority=1, question_name_to_index={'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4}, before_rule=False)]

        The default is that the rule is applied after the question is asked.
        If we want to see the rules that apply before the question is asked, we can set before_rule=True.

        .. code-block:: python

            rule_collection = RuleCollection.example()
            rule_collection.applicable_rules(1)
            [Rule(current_q=1, expression="{{ q1.answer }} == 'yes'", next_q=3, priority=1, question_name_to_index={'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4}), Rule(current_q=1, expression="{{ q1.answer }} == 'no'", next_q=2, priority=1, question_name_to_index={'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4})]

        More than one rule can apply. For example, suppose we are at node 1.
        We could have three rules:
        1. "q1 == 'a' ==> 3
        2. "q1 == 'b' ==> 4
        3. "q1 == 'c' ==> 5
        """
        # Cache rules by position to avoid repeated filtering
        cache_key = (q_now, before_rule)
        if not hasattr(self, "_rules_cache"):
            self._rules_cache = {}

        if cache_key not in self._rules_cache:
            self._rules_cache[cache_key] = [
                rule
                for rule in self
                if rule.current_q == q_now and rule.before_rule == before_rule
            ]

        return self._rules_cache[cache_key]

    def next_question(self, q_now: int, answers: dict[str, Any]) -> NextQuestion:
        """Find the next question by index, given the rule collection.

        This rule is applied after the question is answered.

        :param q_now: The current question index.
        :param answers: The answers to the survey questions so far, including the current question.

        >>> rule_collection = RuleCollection.example()
        >>> rule_collection.next_question(1, {'q1.answer': 'yes'})
        NextQuestion(next_q=3, num_rules_found=2, expressions_evaluating_to_true=1, priority=1)

        """
        expressions_evaluating_to_true = 0
        next_q = None
        highest_priority = -2  # start with -2 to 'pick up' the default rule added
        num_rules_found = 0

        for rule in self.applicable_rules(q_now, before_rule=False):
            num_rules_found += 1
            try:
                if rule.evaluate(answers):  # evaluates to True
                    expressions_evaluating_to_true += 1
                    if rule.priority > highest_priority:  # higher priority
                        # we have a new champ!
                        next_q, highest_priority = rule.next_q, rule.priority
            except SurveyRuleCannotEvaluateError as e:
                # Handle undefined variable errors gracefully
                error_msg = str(e)
                if "is undefined" in error_msg:
                    # Skip rules that reference undefined variables (typically future questions)
                    # This prevents premature evaluation of rules before their variables are available
                    num_rules_found -= 1
                    continue
                else:
                    # Re-raise other evaluation errors (syntax errors, type errors, etc.)
                    raise

        if num_rules_found == 0:
            raise SurveyRuleCollectionHasNoRulesAtNodeError(
                f"No rules found for question {q_now}"
            )

        # Note: Before rules for the next question should be evaluated when we actually
        # get to that question, not now. The current implementation was checking
        # before rules on the next question with incomplete answer context.

        return NextQuestion(
            next_q, num_rules_found, expressions_evaluating_to_true, highest_priority
        )

    def should_stop_survey(
        self, q_answered: int, answers_with_current: dict[str, Any]
    ) -> bool:
        """
        Check if survey should stop after answering a specific question.

        This method should be called AFTER a question is answered, with the answer
        included in the answers dictionary.

        :param q_answered: The question index that was just answered
        :param answers_with_current: Answers including the current question's answer
        :return: True if survey should stop, False otherwise

        >>> rule_collection = RuleCollection()
        >>> from ..base import EndOfSurvey
        >>> stop_rule = Rule(current_q=1, expression="{{ q1.answer }} != 'None'",
        ...                  next_q=EndOfSurvey, priority=0,
        ...                  question_name_to_index={'q1': 1}, before_rule=False)
        >>> rule_collection.add_rule(stop_rule)
        >>> rule_collection.should_stop_survey(1, {'q1.answer': 'yes'})
        True
        >>> rule_collection.should_stop_survey(1, {'q1.answer': 'None'})
        False
        """
        for rule in self.applicable_rules(q_answered, before_rule=False):
            # Only check rules that lead to EndOfSurvey
            if rule.next_q == EndOfSurvey:
                try:
                    if rule.evaluate(answers_with_current):
                        return True
                except SurveyRuleCannotEvaluateError:
                    # If rule can't be evaluated (e.g., missing variables),
                    # don't stop the survey
                    continue
        return False

    @property
    def non_default_rules(self) -> List[Rule]:
        """Return all rules that are not the default rule.

        >>> rule_collection = RuleCollection.example()
        >>> len(rule_collection.non_default_rules)
        2

        Example usage:

        .. code-block:: python

            rule_collection = RuleCollection.example()
            len(rule_collection.non_default_rules)
            2

        """
        return [rule for rule in self if rule.priority > -1]

    def keys_between(self, start_q, end_q, right_inclusive=True):
        """Return a list of all question indices between start_q and end_q.

        Example usage:

        .. code-block:: python

            rule_collection = RuleCollection(num_questions=5)
            rule_collection.keys_between(1, 3)
            [2, 3]
            rule_collection.keys_between(1, 4)
            [2, 3, 4]
            rule_collection.keys_between(1, EndOfSurvey, right_inclusive=False)
            [2, 3]

        """
        # If it's the end of the survey, all questions between the start_q and the end of the survey now depend on the start_q
        if end_q == EndOfSurvey:
            if self.num_questions is None:
                raise ValueError(
                    "Cannot determine DAG when EndOfSurvey and when num_questions is not known."
                )
            end_q = self.num_questions - 1

        question_range = list(range(start_q + 1, end_q + int(right_inclusive)))

        return question_range

    @property
    def dag(self) -> dict:
        """
        Find the DAG of the survey, based on the skip logic.

        Keys are children questions; the list of values are nodes that must be answered first

        Rules are designated at the current question and then direct where
        control goes next. As such, the destination nodes are the keys
        and the current nodes are the values. Furthermore, all questions between
        the current and destination nodes are also included as keys, as they will depend
        on the answer to the focal node as well.

        For exmaple, if we have a rule that says "if {{ q1.answer }} == 'yes', go to q3", then q3 depends on q1, but so does q2.
        So the DAG would be {3: [1], 2: [1]}.

        Example usage:

        .. code-block:: python

            rule_collection = RuleCollection(num_questions=5)
            qn2i = {'q1': 1, 'q2': 2, 'q3': 3, 'q4': 4}
            rule_collection.add_rule(Rule(current_q=1, expression="{{ q1.answer }} == 'yes'", next_q=3, priority=1,  question_name_to_index = qn2i))
            rule_collection.add_rule(Rule(current_q=1, expression="{{ q1.answer }} == 'no'", next_q=2, priority=1, question_name_to_index = qn2i))
            rule_collection.dag
            {2: {1}, 3: {1}}

        """
        children_to_parents = defaultdict(set)
        # We are only interested in non-default rules. Default rules are those
        # that just go to the next question, so they don't add any dependencies

        ## I think for a skip-question, the potenially-skippable question
        ## depends on all the other questions bein answered first.
        for rule in self.non_default_rules:
            if not rule.before_rule:
                # for a regular rule, the next question depends on the current question answer
                current_q, next_q = rule.current_q, rule.next_q
                for q in self.keys_between(current_q, next_q):
                    children_to_parents[q].add(current_q)
            else:
                # for the 'before rule' skipping depends on all previous answers.
                focal_q = rule.current_q
                for q in range(0, focal_q):
                    children_to_parents[focal_q].add(q)

        return DAG(dict(sorted(children_to_parents.items())))

    def detect_cycles(self):
        """
        Detect cycles in the survey rules using depth-first search.

        :return: A list of cycles if any are found, otherwise an empty list.
        """
        dag = self.dag
        visited = set()
        path = []
        cycles = []

        def dfs(node):
            if node in path:
                cycle = path[path.index(node) :]
                cycles.append(cycle + [node])
                return

            if node in visited:
                return

            visited.add(node)
            path.append(node)

            for child in dag.get(node, []):
                dfs(child)

            path.pop()

        for node in dag:
            if node not in visited:
                dfs(node)

        return cycles

    @classmethod
    def example(cls):
        """Create an example RuleCollection object."""
        qn2i = {"q1": 1, "q2": 2, "q3": 3, "q4": 4}
        return cls(
            num_questions=5,
            rules=[
                Rule(
                    current_q=1,
                    expression="{{ q1.answer }} == 'yes'",
                    next_q=3,
                    priority=1,
                    question_name_to_index=qn2i,
                ),
                Rule(
                    current_q=1,
                    expression="{{ q1.answer }} == 'no'",
                    next_q=2,
                    priority=1,
                    question_name_to_index=qn2i,
                ),
            ],
        )


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)
